<?php
/**
 * POST /api/upload  (multipart/form-data)
 * Fields: file (required), caption, related_type, related_id
 *
 * Saves the image to /public/uploads/photos with a collision-safe name,
 * then inserts a row into `photos` and returns it (including the public URL)
 * so the frontend can immediately use it in the gallery or attach it to an
 * officer/timeline/achievement entry.
 * Requires authentication.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/auth_middleware.php';

ypd_send_json_headers();

// Require authentication for file uploads
requireAuth();

$pdo = getDb();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ypd_error('Method not allowed', 405);
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    ypd_error('No valid file uploaded (field name must be "file").', 422);
}

$file = $_FILES['file'];

if ($file['size'] > MAX_UPLOAD_BYTES) {
    ypd_error('File too large. Max ' . (MAX_UPLOAD_BYTES / 1024 / 1024) . 'MB.', 413);
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mime, ALLOWED_IMAGE_TYPES, true)) {
    ypd_error('Unsupported file type. Allowed: JPEG, PNG, WEBP.', 422);
}

$extMap = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$ext = $extMap[$mime];
$safeName = 'ypd_' . bin2hex(random_bytes(8)) . '.' . $ext;

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0775, true);
}

$destination = UPLOAD_DIR . '/' . $safeName;
if (!move_uploaded_file($file['tmp_name'], $destination)) {
    ypd_error('Failed to save uploaded file.', 500);
}

$caption = $_POST['caption'] ?? null;
$relatedType = $_POST['related_type'] ?? null;
$relatedId = isset($_POST['related_id']) ? (int) $_POST['related_id'] : null;

$stmt = $pdo->prepare('INSERT INTO photos (filename, caption, related_type, related_id) VALUES (:filename, :caption, :related_type, :related_id)');
$stmt->execute([
    ':filename' => $safeName,
    ':caption' => $caption,
    ':related_type' => $relatedType,
    ':related_id' => $relatedId,
]);
$id = $pdo->lastInsertId();

$stmt = $pdo->prepare('SELECT * FROM photos WHERE id = :id');
$stmt->execute([':id' => $id]);
$row = $stmt->fetch();
$row['url'] = UPLOAD_URL_BASE . '/' . $safeName;

ypd_respond($row, 201);
