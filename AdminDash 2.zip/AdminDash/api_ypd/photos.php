<?php
// /api/photos[/{id}] — gallery metadata (the actual files are handled by upload.php)
// GET is public, POST/PUT/DELETE require authentication
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/crud_helper.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/auth_middleware.php';

ypd_send_json_headers();

$method = $_SERVER['REQUEST_METHOD'];
$requireAuth = ($method !== 'GET');

ypd_handle_crud(
    table: 'photos',
    allowedFields: ['filename', 'caption', 'related_type', 'related_id'],
    requiredOnCreate: ['filename'],
    orderBy: 'uploaded_at DESC',
    requireAuth: $requireAuth
);
