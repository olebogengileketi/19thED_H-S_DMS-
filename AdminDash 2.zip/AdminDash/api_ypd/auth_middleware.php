<?php
/**
 * auth_middleware.php - Authentication middleware for YPD API endpoints
 * INTEGRATED VERSION: Uses AdminDash authentication system
 * Call requireAuth() at the beginning of any API endpoint that requires authentication
 */

// Load AdminDash authentication
require_once __DIR__ . '/../includes/auth.php';

/**
 * Require authentication for API endpoint
 * Returns 401 if user is not authenticated
 */
function requireAuth(): void {
    ensure_session_started();
    
    $user = current_auth_user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
}

/**
 * Require specific role for API endpoint
 * @param array $allowedRoles - AdminDash roles (superadmin, conference_admin)
 */
function requireApiRole(array $allowedRoles): void {
    requireAuth();
    
    $user = current_auth_user();
    if (!$user || !in_array($user['role'], $allowedRoles, true)) {
        http_response_code(403);
        echo json_encode(['error' => 'Insufficient permissions']);
        exit;
    }
}

/**
 * Optional authentication - doesn't fail if not authenticated, but provides user info if available
 * @return array|null User data if authenticated, null otherwise
 */
function getOptionalAuth(): ?array {
    ensure_session_started();
    return current_auth_user();
}