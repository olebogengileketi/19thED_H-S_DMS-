<?php
// /api_ypd/timeline[/{id}] — chronological milestones
// GET is public, POST/PUT/DELETE require authentication
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/crud_helper.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/auth_middleware.php';

ypd_send_json_headers();

$method = $_SERVER['REQUEST_METHOD'];
$requireAuth = ($method !== 'GET');

ypd_handle_crud(
    table: 'ypd_timeline_events',
    allowedFields: ['event_date', 'title', 'description', 'sort_order'],
    requiredOnCreate: ['event_date', 'title'],
    orderBy: 'event_date ASC, sort_order ASC',
    requireAuth: $requireAuth
);
