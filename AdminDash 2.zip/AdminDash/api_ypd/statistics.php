<?php
// /api_ypd/statistics[/{id}] — membership/event/mission numbers for the statistician side of the role
// GET is public, POST/PUT/DELETE require authentication
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/crud_helper.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/auth_middleware.php';

ypd_send_json_headers();

$method = $_SERVER['REQUEST_METHOD'];
$requireAuth = ($method !== 'GET');

ypd_handle_crud(
    table: 'ypd_statistics',
    allowedFields: ['category', 'label', 'value', 'unit', 'year', 'sort_order'],
    requiredOnCreate: ['category', 'label', 'value'],
    requireAuth: $requireAuth
);
