<?php
/**
 * config.php
 * Central configuration for the YPD 19th Episcopal District History Booklet API.
 * 
 * INTEGRATED VERSION: Now uses AdminDash database connection for unified system
 */

// Load AdminDash configuration
$adminConfig = require __DIR__ . '/../config.php';

// ---- Driver selection - Force MySQL (using AdminDash database) -------------
define('DB_DRIVER', 'mysql');

// ---- MySQL settings (using AdminDash database) -------------
define('MYSQL_HOST', $adminConfig['db']['host']);
define('MYSQL_PORT', $adminConfig['db']['port']);
define('MYSQL_NAME', $adminConfig['db']['name']);
define('MYSQL_USER', $adminConfig['db']['user']);
define('MYSQL_PASS', $adminConfig['db']['pass']);

// ---- Uploads (integrated with AdminDash media uploads) --------------------
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/ypd_photos');
define('UPLOAD_URL_BASE', $adminConfig['urls']['base'] . '/assets/uploads/ypd_photos');
define('MAX_UPLOAD_BYTES', 5 * 1024 * 1024); // 5MB per photo
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);

// ---- General ----------------------------------------------------------
define('BOOKLET_ORG_NAME', '19th Episcopal District — Young People\'s Division (YPD)');
define('APP_TIMEZONE', 'UTC');
date_default_timezone_set(APP_TIMEZONE);

// ---- CORS / JSON headers (API is same-origin by default; loosened for local dev) --
function ypd_send_json_headers() {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
}
