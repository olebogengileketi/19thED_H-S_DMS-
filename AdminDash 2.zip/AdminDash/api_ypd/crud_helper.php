<?php
/**
 * crud_helper.php
 * A small, generic CRUD dispatcher shared by history/officers/timeline/
 * achievements/statistics/photos. Each endpoint file is ~10 lines that just
 * declares its table name, allowed fields, and required-on-create fields,
 * then calls ypd_handle_crud(). Keeps behavior identical across resources
 * and means new chapter types can be added in minutes.
 *
 * Route id (the {id} in /api/{resource}/{id}) comes from $GLOBALS['ypd_route_id'],
 * set by router.php.
 */

function ypd_handle_crud(string $table, array $allowedFields, array $requiredOnCreate = [], string $orderBy = 'sort_order ASC, id ASC', bool $requireAuth = false): void {
    // Require authentication if specified
    if ($requireAuth) {
        require_once __DIR__ . '/auth.php';
        require_once __DIR__ . '/auth_middleware.php';
        requireAuth();
    }
    
    $pdo = getDb();
    $method = $_SERVER['REQUEST_METHOD'];
    // Under Apache the /resource/{id} form isn't routed here, so accept ?id= too
    $id = $GLOBALS['ypd_route_id'] ?? ($_GET['id'] ?? null);

    if ($method === 'GET') {
        if ($id !== null) {
            $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $row = $stmt->fetch();
            if (!$row) ypd_error('Not found', 404);
            ypd_respond($row);
        }

        // Optional simple filtering, e.g. ?category=Membership or ?year=2023
        $where = [];
        $params = [];
        foreach ($_GET as $key => $val) {
            if (in_array($key, $allowedFields, true)) {
                $where[] = "$key = :f_$key";
                $params[":f_$key"] = $val;
            }
        }
        $sql = "SELECT * FROM $table";
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $sql .= " ORDER BY $orderBy";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        ypd_respond($stmt->fetchAll());
    }

    if ($method === 'POST') {
        $data = ypd_json_input();
        ypd_require_fields($data, $requiredOnCreate);

        $cols = [];
        $placeholders = [];
        $params = [];
        foreach ($allowedFields as $field) {
            if (array_key_exists($field, $data)) {
                $cols[] = $field;
                $placeholders[] = ":$field";
                $params[":$field"] = $data[$field];
            }
        }
        if (empty($cols)) ypd_error('No valid fields provided.', 422);

        $sql = "INSERT INTO $table (" . implode(', ', $cols) . ') VALUES (' . implode(', ', $placeholders) . ')';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $newId = $pdo->lastInsertId();

        $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = :id");
        $stmt->execute([':id' => $newId]);
        ypd_respond($stmt->fetch(), 201);
    }

    if ($method === 'PUT' || $method === 'PATCH') {
        if ($id === null) ypd_error('Missing id in URL, e.g. /api/' . $table . '/5', 400);
        $data = ypd_json_input();

        $sets = [];
        $params = [':id' => $id];
        foreach ($allowedFields as $field) {
            if (array_key_exists($field, $data)) {
                $sets[] = "$field = :$field";
                $params[":$field"] = $data[$field];
            }
        }
        if (empty($sets)) ypd_error('No updatable fields provided.', 422);

        if (array_key_exists('updated_at', $data) && columnExists($pdo, $table, 'updated_at')) {
            $sets[] = 'updated_at = ' . (DB_DRIVER === 'mysql' ? 'NOW()' : "datetime('now')");
        }

        $sql = "UPDATE $table SET " . implode(', ', $sets) . ' WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        if (!$row) ypd_error('Not found', 404);
        ypd_respond($row);
    }

    if ($method === 'DELETE') {
        if ($id === null) ypd_error('Missing id in URL, e.g. /api/' . $table . '/5', 400);
        $stmt = $pdo->prepare("DELETE FROM $table WHERE id = :id");
        $stmt->execute([':id' => $id]);
        if ($stmt->rowCount() === 0) ypd_error('Not found', 404);
        ypd_respond(['deleted' => true, 'id' => $id]);
    }

    ypd_error('Method not allowed', 405);
}

function columnExists(PDO $pdo, string $table, string $column): bool {
    static $cache = [];
    $key = "$table.$column";
    if (isset($cache[$key])) return $cache[$key];

    if (DB_DRIVER === 'mysql') {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM $table LIKE :col");
        $stmt->execute([':col' => $column]);
        $exists = (bool) $stmt->fetch();
    } else {
        $stmt = $pdo->query("PRAGMA table_info($table)");
        $exists = false;
        foreach ($stmt->fetchAll() as $col) {
            if ($col['name'] === $column) { $exists = true; break; }
        }
    }
    return $cache[$key] = $exists;
}
