<?php
require_once '../includes/access_control.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../views/media.php');
    exit;
}

$leader_id = (int)($_POST['leader_id'] ?? 0);
if ($leader_id <= 0) {
    header('Location: ../views/media.php?error=Invalid leader ID');
    exit;
}

$role = trim($_POST['role_type'] ?? 'Other');
$name = trim($_POST['full_name'] ?? '');
$conference = trim($_POST['conference_name'] ?? '');
$startYear = (int)($_POST['start_year'] ?? 0) ?: null;
$endYear = (int)($_POST['end_year'] ?? 0) ?: null;
$descriptions = trim($_POST['descriptions'] ?? '');
$achievements = trim($_POST['achievements'] ?? '');
$removePhoto = isset($_POST['remove_photo']);

if ($name === '') {
    header('Location: ../views/media.php?error=Leader name is required');
    exit;
}

// Get current photo path
$stmt = $pdo->prepare("SELECT photo_path FROM legacy_leaders WHERE leader_id = ?");
$stmt->execute([$leader_id]);
$currentLeader = $stmt->fetch();
$currentPhotoPath = $currentLeader['photo_path'] ?? null;

$photoPath = $currentPhotoPath;

// Handle photo removal
if ($removePhoto && $currentPhotoPath) {
    $photoPath = null;
    // Delete the file
    $filePath = '../' . $currentPhotoPath;
    if (file_exists($filePath)) {
        unlink($filePath);
    }
}

// Handle photo upload
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = '../uploads/leaders/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
    $filename = uniqid('leader_') . '.' . $ext;
    $destination = $uploadDir . $filename;
    if (move_uploaded_file($_FILES['photo']['tmp_name'], $destination)) {
        // Delete old photo if exists
        if ($currentPhotoPath) {
            $oldFilePath = '../' . $currentPhotoPath;
            if (file_exists($oldFilePath)) {
                unlink($oldFilePath);
            }
        }
        $photoPath = 'uploads/leaders/' . $filename;
    }
}

$stmt = $pdo->prepare("UPDATE legacy_leaders SET role_type = ?, full_name = ?, conference_name = ?, start_year = ?, end_year = ?, descriptions = ?, achievements = ?, photo_path = ? WHERE leader_id = ?");
$stmt->execute([$role, $name, $conference ?: null, $startYear, $endYear, $descriptions ?: null, $achievements ?: null, $photoPath, $leader_id]);

header('Location: ../views/media.php?leader_updated=1');
exit;